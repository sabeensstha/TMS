<?php return array (
  'dashboard' => 'App\\Http\\Livewire\\Dashboard',
  'landing-page' => 'App\\Http\\Livewire\\LandingPage',
  'login' => 'App\\Http\\Livewire\\Login',
);