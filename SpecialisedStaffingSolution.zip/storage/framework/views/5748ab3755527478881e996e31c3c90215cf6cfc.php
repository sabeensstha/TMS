<div>
    <div class="flex flex-col lg:flex-row w-screen h-screen justify-center items-center">
        <form wire:submit.prevent="authenticate" class="w-full lg:h-3/4 lg:w-6/12 shadow bg-blue-100 rounded-3xl flex flex-col justify-center items-center">
            <label class="text-gray-700 font-bold" for="email">Email</label>
            <input id="email" wire:model.lazy="email" type="email" class="bg-gray-100 px-3 py-2 border border-gray-400 placeholder-gray-400 text-black rounded-lg w-1/2" placeholder="Enter email address">
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-red-700"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <label class="text-gray-700 font-bold text-left mt-6" for="password">Password</label>
            <input id="password" wire:model.lazy="password" type="password" class="bg-gray-100 px-3 py-2 border border-gray-400 placeholder-gray-400 text-black rounded-lg w-1/2" placeholder="Enter password">
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-red-700"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <button class="mt-5 py-3 px-6 rounded-lg border-b-2 border-blue-500 bg-gray-200 hover:border-blue-900" type="submit">Login</button>
        </form>
    </div>
</div>
<?php /**PATH /Applications/MAMP/htdocs/laravel/livewire/SpecialisedStaffingSolution/resources/views/livewire/login.blade.php ENDPATH**/ ?>