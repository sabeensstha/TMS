<div>
    <p>
        You have successfully logged in
    </p>
    <p class="text-xl">
        <?php echo e(auth()->user()->name); ?>

    </p>
</div>
<?php /**PATH /Applications/MAMP/htdocs/laravel/livewire/SpecialisedStaffingSolution/resources/views/livewire/dashboard.blade.php ENDPATH**/ ?>