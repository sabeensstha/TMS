<div>
    <p>
        You have successfully logged in
    </p>
    <p class="text-xl">
        {{ auth()->user()->name }}
    </p>
</div>
