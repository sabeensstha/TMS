<div>
    <div class="w-screen h-screen flex flex-col items-center justify-center">
        <img src="{{ asset('statics/logo.jpeg') }}" alt="Logo" class="my-3 p-2">
        <a class="items-center px-8 py-2 font-semibold text-white transition duration-500 ease-in-out transform bg-black rounded-lg hover:bg-gray-900 focus:ring focus:outline-none" href="{{ route('login') }}">Login</a>
    </div>
</div>
